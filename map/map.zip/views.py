from django.shortcuts import render, redirect, render_to_response
from django.http import HttpResponse, HttpResponseRedirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import UserCreationForm
from django.urls import reverse
from django.shortcuts import render
from django.contrib import auth
from .models import *

# Create your views here.


def index(request):
    if request.method == "POST":  # 如果是以POST的方式才處理
        a = request.POST['search']

        searchevent = Booth.objects.filter(desc__contains=a)
        context = {'searchevent': searchevent}
        return render(request, "search.html", context)
    return render(request, 'index.html', locals())


def map(request):
    num = Event.objects.all()

    booth = Booth.objects.all()
    content = {'num': num, ' booth': booth}
    return render(request, 'eventlist.html', content)


def boothmap(request, id):
    num = Event.objects.get(id=id)
    content = {'num': num}
    return render(request, 'map.html', content)


def inf(request, id, pk):
    user = User.objects.get(id=request.user.id)

    num = Event.objects.get(id=id)
    boothinf = Booth.objects.all()
    boothpk = Booth.objects.get(pk=pk)
    if request.method == "POST":  # 如果是以POST的方式才處理
        User_Favorite_Booth.objects.create(user=user, booth=boothpk)
        return render(request, 'information.html', locals())

    return render(request, 'information.html', locals())


def edit(request, id, pk):

    num = Event.objects.get(id=id)
    boothpk = Booth.objects.get(pk=pk)
    if request.method == "POST":  # 如果是以POST的方式才處理
        boothpk.number = request.POST['number']
        boothpk.group_name = request.POST['groupname']  # 取得表單輸入資料
        boothpk.desc = request.POST['desc']
        boothpk.works_type = request.POST['workstype']
        boothpk.works_tag = request.POST['workstag']

        image = request.FILES.get('image')
        if image.size < 2621440:
            boothpk.image = image
        #new!!! 限制單檔2.5MB

        boothpk.save()  # 寫入資料庫
        return redirect(reverse('inf', args=(id, pk,)))  # 重導到<index.html>網頁
    else:
        try:
            boothpk = Booth.objects.get(pk=pk)
        except:
            message = '此ID不存在'
    return render(request, "edit.html", locals())


def add(request, id):

    num = Event.objects.get(id=id)

    if request.method == "POST":  # 如果是以POST的方式才處理
        number = request.POST['number']
        group_name = request.POST['groupname']  # 取得表單輸入資料
        desc = request.POST['desc']
        works_type = request.POST['workstype']
        works_tag = request.POST['workstag']
        Booth.objects.create(event=num, number=number, group_name=group_name,
                             desc=desc, works_type=works_type, works_tag=works_tag)  # 寫入資料庫

    return render(request, "add.html", locals())


def login(request):
    if request.user.is_authenticated():
        return redirect('/index')

    username = request.POST.get('username', '')
    password = request.POST.get('password', '')
    user = auth.authenticate(username=username, password=password)
    if user is not None and user.is_active:
        auth.login(request, user)
        return HttpResponseRedirect('/index/')
    else:
        return render(request, "login.html", locals())


def logout(request):
    auth.logout(request)
    return HttpResponseRedirect('/index/')


def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            auth.login(request, user)
            return redirect('/index')
    else:
        form = UserCreationForm()
    return render(request, 'register.html', {'form': form})


def search(request):

    if request.method == "POST":  # 如果是以POST的方式才處理
        a = request.POST['search']

        searchevent = Booth.objects.filter(desc__contains=a)
        context = {'searchevent': searchevent}
        return render(request, "search.html", context)

    return render(request, "search.html", locals())
